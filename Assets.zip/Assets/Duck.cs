using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using UnityEngine.Events;


public class Duck : MonoBehaviour
{
    [SerializeField, Range(0,1)] float moveDuration;
    [SerializeField, Range(0,1)] float jumpHeight = 0.5f;
    [SerializeField] int leftMoveLimit;
    [SerializeField] int rightMoveLimit;
    [SerializeField] int backMoveLimit;
    [SerializeField] AudioSource getCoin;
    [SerializeField] AudioSource duckDie;


    public UnityEvent <Vector3> OnJumpEnd;
    public UnityEvent <int> OnGetCoin;
    public UnityEvent OnCarCollision;
    public UnityEvent OnDie;
    // public UnityEvent OncoinCollected;

    private bool isMovable = false;


    void Update()
    {
        if(isMovable == false )
            return;

        if (DOTween.IsTweening(transform))
        return;

        Vector3 direction = Vector3.zero;

        if (Input.GetKeyDown(KeyCode.W ) ||Input.GetKeyDown (KeyCode.UpArrow))
        {
           direction += Vector3.forward;
        }
        else if (Input.GetKeyDown(KeyCode.S ) ||Input.GetKeyDown (KeyCode.DownArrow))
        {
           direction += Vector3.back;
        }
        else if (Input.GetKeyDown(KeyCode.A ) ||Input.GetKeyDown (KeyCode.LeftArrow))
        {
            direction += Vector3.left;
        }
        else if (Input.GetKeyDown(KeyCode.D ) ||Input.GetKeyDown (KeyCode.RightArrow))
        {
             direction += Vector3.right;
        }

        if(direction == Vector3.zero)
            return;

         Move(direction);


    }

    public void Move(Vector3 direction)
    {
        var targetPosition = transform.position + direction;

        if(targetPosition.x < leftMoveLimit ||
            targetPosition.x > rightMoveLimit ||
            targetPosition.z < backMoveLimit ||
            Tree.AllPosition.Contains(targetPosition))
        {
            targetPosition = transform.position;
        }

        transform.DOJump(targetPosition, jumpHeight, 1, moveDuration).onComplete = BroadCastPositionOnJumpEnd;

        transform.forward = direction;
    }

    public void SetMoveable(bool value)
    {
        isMovable = value;
    }

    public void UpdateMoveLimit(int horizontalSize, int backLimit)
    {
        leftMoveLimit = -horizontalSize/2;
        rightMoveLimit = horizontalSize/2;
        backMoveLimit = backLimit;
    }

    private void BroadCastPositionOnJumpEnd(){
        OnJumpEnd.Invoke(transform.position);
    }

    private void OnTriggerEnter(Collider other)
    {

        if(other.CompareTag("Car") && isMovable)
        {

            if(transform.localScale.y == 0.2f)
                return;


            transform.DOScale(new Vector3(1.3f,0.2f,1.3f),0.2f);
            // transform.DOJump(Vector3.back,10,1,1);

            isMovable = false;
            OnCarCollision.Invoke();
            duckDie.Play();
            Invoke("Die", 3);
            
        }
        

        else if(other.CompareTag("Coin"))
        {
            var coin = other.GetComponent<Coin>();
            OnGetCoin.Invoke(coin.Value);
            coin.Collected();
            // OncoinCollected.Invoke();
            getCoin.Play();
            
        }
        else if(other.CompareTag("Eagle"))
        {
            if(this.transform != other.transform)
            {
            this.transform.SetParent(other.transform);
            
            if(isMovable != false)
            Invoke("Die", 3);
            }
        }
    }

    private void Die()
    {
        OnDie.Invoke();
        // popUp.Play();

    }

}
