using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Road : Terrain
{
    [SerializeField] List <Car> carPrefabList;
    [SerializeField] float minCarSpawnInterval;
    [SerializeField] float maxCarSpawnInterval;
    // [SerializeField] AudioSource carSound;

    public UnityEvent carInstantiate;

    float timer;

    Vector3 carSpawnPosition;
    Quaternion carRotation;

    private void Start()
    {
        if (Random.value > 0.5f)
        {
            carSpawnPosition = new Vector3(horizontalSize/ 2 + 10, 0, this.transform.position.z);
            carRotation = Quaternion.Euler(0,0,0);
        } 
        else
        {
            carSpawnPosition = new Vector3(-(horizontalSize/ 2 + 10), 0, this.transform.position.z);
            carRotation = Quaternion.Euler(0,-180,0);
        }
    }

    private void Update()
    {
        if(timer <= 0)
        {
            
            timer = Random.Range(minCarSpawnInterval, maxCarSpawnInterval);
            
            var randomIndex = Random.Range(0, carPrefabList.Count);
            var carPrefab = carPrefabList[randomIndex];
            
            var car = Instantiate(carPrefab, carSpawnPosition, carRotation);
            car.SetupDistanceLimit(horizontalSize + 30);
            // carSound.Play();
            // float volume = carSound.volume;
            // audioManager.SetSfxVolume(volume);
            carInstantiate.Invoke();
            
            return;
            
        }
        timer -= Time.deltaTime;
        
    }


    

}
