using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using DG.Tweening;

public class PlayCountDown : MonoBehaviour
{
    [SerializeField] TMPro.TMP_Text tmpText;
    // [SerializeField] AudioSource countSound;
    public UnityEvent OnStart;
    public UnityEvent OnEnd;

    private void Start(){

        var Sequence = DOTween.Sequence();
        tmpText.transform.localScale = Vector3.zero;
        tmpText.text = "";
        

        Sequence.Append(tmpText.transform.DOScale(
            Vector3.one, 0.1f)
            .OnComplete(() => {
                tmpText.transform.localScale = Vector3.zero;
                tmpText.text = "3";
                OnStart.Invoke();}));

        Sequence.Append(tmpText.transform.DOScale(
            Vector3.one, 1)
            .OnComplete(() => {
                tmpText.transform.localScale = Vector3.zero;
                tmpText.text = "2";}));

        Sequence.Append(tmpText.transform.DOScale(
            Vector3.one, 1)
            .OnComplete(() => {
                tmpText.transform.localScale = Vector3.zero;
                tmpText.text = "1";}));


        Sequence.Append(tmpText.transform.DOScale(
            Vector3.one, 1)
            .OnComplete(() => {
                tmpText.transform.localScale = Vector3.zero;
                tmpText.text = "GO!";}));

        Sequence.Append(tmpText.transform.DOScale(
            Vector3.one, 1)
            .OnComplete(() => {
                OnEnd.Invoke();}));

    }
    
}
